﻿namespace AttStat.Models
{
    class GenericStudent
    {
        public int Id { get; set; }
        public string? Fio { get; set; }
        public int Course { get; set; }
    }
}
